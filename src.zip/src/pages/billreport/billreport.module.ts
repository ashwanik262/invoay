import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BillreportPage } from './billreport';

@NgModule({
  declarations: [
    BillreportPage,
  ],
  imports: [
    IonicPageModule.forChild(BillreportPage),
  ],
})
export class BillreportPageModule {}
